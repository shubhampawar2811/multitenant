"""
Multi-Tenant Cloud — Flask Application (Full Version)
Features:
  • Register / Login (JWT)
  • All-tenants global view (metadata only for other tenants)
  • Add records + file/doc attachment (local or AWS S3)
  • View / delete own records and files
  • Cross-tenant attack simulation with proper logging
  • AWS Bedrock Claude AI analysis (demo mode if not configured)
  • Admin panel metrics
Run:  python app.py
"""
import os, io, uuid, mimetypes
from datetime import datetime, timezone, timedelta
from functools import wraps

import jwt as pyjwt
from flask import Flask, request, jsonify, render_template, g, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

from encryption import encrypt_data, decrypt_data
from database import get_db, init_schema
import metrics as metrics_module

app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
JWT_SECRET  = os.environ.get('JWT_SECRET', 'multi-tenant-jwt-secret-2024')
JWT_EXPIRES = 3600  # 1 hour

# AWS (set USE_S3=true to enable S3 file storage + Bedrock AI)
USE_AWS     = os.environ.get('USE_S3', 'false').lower() == 'true'
S3_BUCKET   = os.environ.get('S3_BUCKET', 'my-multitenant-bucket')
AWS_REGION  = os.environ.get('AWS_REGION', 'us-east-1')

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'instance', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {
    'pdf','doc','docx','xls','xlsx','ppt','pptx',
    'png','jpg','jpeg','gif','webp','svg',
    'txt','csv','json','xml','zip','mp4','mp3','wav'
}

_s3      = None
_bedrock = None

def get_s3():
    global _s3
    if _s3 is None:
        import boto3
        _s3 = boto3.client('s3', region_name=AWS_REGION)
    return _s3

def get_bedrock():
    global _bedrock
    if _bedrock is None:
        import boto3
        _bedrock = boto3.client('bedrock-runtime', region_name=AWS_REGION)
    return _bedrock

# ── DB helpers ────────────────────────────────────────────────────────────────
def db():
    if 'db' not in g:
        g.db = get_db()
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    d = g.pop('db', None)
    if d: d.close()

# ── JWT helpers ───────────────────────────────────────────────────────────────
def make_token(payload: dict) -> str:
    payload = dict(payload)
    payload['exp'] = datetime.now(timezone.utc) + timedelta(seconds=JWT_EXPIRES)
    return pyjwt.encode(payload, JWT_SECRET, algorithm='HS256')

def decode_token(token: str):
    return pyjwt.decode(token, JWT_SECRET, algorithms=['HS256'])

def jwt_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get('Authorization', '')
        if not auth.startswith('Bearer '):
            return jsonify({'error': 'Missing token'}), 401
        try:
            g.jwt_payload = decode_token(auth.split(' ', 1)[1])
        except pyjwt.ExpiredSignatureError:
            return jsonify({'error': 'Token expired'}), 401
        except Exception:
            return jsonify({'error': 'Invalid token'}), 401
        return f(*args, **kwargs)
    return wrapper

def current_user():
    uid = g.jwt_payload['user_id']
    return db().execute(
        "SELECT u.*, t.name AS tenant_name FROM users u "
        "JOIN tenants t ON t.id = u.tenant_id WHERE u.id = ?", (uid,)
    ).fetchone()

def log_event(action, status, user_id=None, tenant_id=None,
              resource_tenant_id=None, details=None):
    try:
        c = get_db()
        c.execute(
            "INSERT INTO security_logs "
            "(action,status,user_id,tenant_id,resource_tenant_id,ip_address,details) "
            "VALUES (?,?,?,?,?,?,?)",
            (action, status, user_id, tenant_id, resource_tenant_id,
             request.remote_addr, details)
        )
        c.commit(); c.close()
    except Exception:
        pass

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ── Pages ─────────────────────────────────────────────────────────────────────
@app.route('/')
def index():        return render_template('index.html')
@app.route('/login-page')
def login_page():   return render_template('login.html')
@app.route('/dashboard')
def dashboard():    return render_template('dashboard.html')
@app.route('/admin-page')
def admin_page():   return render_template('admin.html')

# ── Auth ──────────────────────────────────────────────────────────────────────
@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    for field in ('username', 'email', 'password', 'tenant_name'):
        if not data.get(field):
            return jsonify({'error': f'Field "{field}" is required'}), 400
    conn = db()
    t = conn.execute("SELECT id FROM tenants WHERE name=?", (data['tenant_name'],)).fetchone()
    if not t:
        cur = conn.execute("INSERT INTO tenants (name) VALUES (?)", (data['tenant_name'],))
        conn.commit()
        tenant_id = cur.lastrowid
    else:
        tenant_id = t['id']
    if conn.execute("SELECT id FROM users WHERE username=?", (data['username'],)).fetchone():
        return jsonify({'error': 'Username already exists'}), 409
    if conn.execute("SELECT id FROM users WHERE email=?", (data['email'],)).fetchone():
        return jsonify({'error': 'Email already registered'}), 409
    ph  = generate_password_hash(data['password'])
    cur = conn.execute(
        "INSERT INTO users (username,email,password_hash,role,tenant_id) VALUES (?,?,?,?,?)",
        (data['username'], data['email'], ph, data.get('role','user'), tenant_id)
    )
    conn.commit()
    log_event('REGISTER', 'SUCCESS', user_id=cur.lastrowid, tenant_id=tenant_id)
    return jsonify({'message': 'Registration successful', 'tenant_id': tenant_id}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    row  = db().execute("SELECT * FROM users WHERE username=?", (data.get('username'),)).fetchone()
    if not row or not check_password_hash(row['password_hash'], data.get('password', '')):
        log_event('LOGIN', 'FAILED', details=f"Bad login: {data.get('username')}")
        return jsonify({'error': 'Invalid credentials'}), 401
    if not row['is_active']:
        return jsonify({'error': 'Account disabled'}), 403
    t     = db().execute("SELECT name FROM tenants WHERE id=?", (row['tenant_id'],)).fetchone()
    token = make_token({'user_id': row['id'], 'tenant_id': row['tenant_id'], 'role': row['role']})
    log_event('LOGIN', 'SUCCESS', user_id=row['id'], tenant_id=row['tenant_id'])
    return jsonify({'access_token': token, 'user': {
        'id': row['id'], 'username': row['username'], 'email': row['email'],
        'role': row['role'], 'tenant_id': row['tenant_id'],
        'tenant_name': t['name'] if t else None
    }})

@app.route('/api/me')
@jwt_required
def me():
    u = current_user()
    if not u: return jsonify({'error': 'User not found'}), 404
    return jsonify({
        'id': u['id'], 'username': u['username'], 'email': u['email'],
        'role': u['role'], 'tenant_id': u['tenant_id'], 'tenant_name': u['tenant_name']
    })

# ── Data Records ──────────────────────────────────────────────────────────────
@app.route('/api/data/all')
@jwt_required
def get_all_data():
    """All tenants — metadata visible, content only for own tenant."""
    u    = current_user()
    rows = db().execute(
        "SELECT d.*, t.name AS tenant_name, u2.username AS creator "
        "FROM tenant_data d "
        "JOIN tenants t ON t.id = d.tenant_id "
        "LEFT JOIN users u2 ON u2.id = d.created_by "
        "ORDER BY d.created_at DESC"
    ).fetchall()
    records = []
    for r in rows:
        own = (r['tenant_id'] == u['tenant_id'])
        # attach file info
        f = db().execute(
            "SELECT original_name, mime_type FROM tenant_files WHERE record_id=? LIMIT 1", (r['id'],)
        ).fetchone()
        records.append({
            'id':          r['id'],
            'tenant_id':   r['tenant_id'],
            'tenant_name': r['tenant_name'],
            'title':       r['title'],
            'content':     decrypt_data(r['content']) if own else '🔒 Access Restricted',
            'data_type':   r['data_type'],
            'created_at':  r['created_at'],
            'is_sensitive':bool(r['is_sensitive']),
            'accessible':  own,
            'has_file':    f is not None,
            'file_name':   f['original_name'] if f else None,
        })
    log_event('DATA_ALL_ACCESS', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'])
    return jsonify({'records': records, 'my_tenant_id': u['tenant_id']})

@app.route('/api/data')
@jwt_required
def get_data():
    """Own tenant records only."""
    u    = current_user()
    rows = db().execute(
        "SELECT d.*, u2.username AS creator FROM tenant_data d "
        "LEFT JOIN users u2 ON u2.id = d.created_by "
        "WHERE d.tenant_id=? ORDER BY d.created_at DESC", (u['tenant_id'],)
    ).fetchall()
    records = []
    for r in rows:
        f = db().execute(
            "SELECT id, original_name, file_size, mime_type FROM tenant_files WHERE record_id=? LIMIT 1",
            (r['id'],)
        ).fetchone()
        records.append({
            'id':          r['id'],
            'tenant_id':   r['tenant_id'],
            'title':       r['title'],
            'content':     decrypt_data(r['content']),
            'data_type':   r['data_type'],
            'created_at':  r['created_at'],
            'is_sensitive':bool(r['is_sensitive']),
            'creator':     r['creator'],
            'file':        dict(f) if f else None,
        })
    log_event('DATA_ACCESS', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'],
              resource_tenant_id=u['tenant_id'])
    return jsonify({'records': records, 'tenant_id': u['tenant_id']})

@app.route('/api/data', methods=['POST'])
@jwt_required
def create_data():
    """Create a record. Optionally attach a file (multipart or JSON)."""
    u = current_user()

    # Support both multipart (with file) and JSON
    if request.content_type and 'multipart' in request.content_type:
        title     = request.form.get('title', '').strip()
        content   = request.form.get('content', '').strip()
        data_type = request.form.get('data_type', 'general')
        is_sens   = int(request.form.get('is_sensitive', 1))
        file_obj  = request.files.get('file')
    else:
        data      = request.get_json() or {}
        title     = data.get('title', '').strip()
        content   = data.get('content', '').strip()
        data_type = data.get('data_type', 'general')
        is_sens   = int(data.get('is_sensitive', 1))
        file_obj  = None

    if not title or not content:
        return jsonify({'error': 'title and content are required'}), 400

    enc = encrypt_data(content)
    cur = db().execute(
        "INSERT INTO tenant_data (tenant_id,title,content,data_type,created_by,is_sensitive) "
        "VALUES (?,?,?,?,?,?)",
        (u['tenant_id'], title, enc, data_type, u['id'], is_sens)
    )
    db().commit()
    record_id = cur.lastrowid

    # Handle optional file attachment
    file_id = None
    if file_obj and file_obj.filename and allowed_file(file_obj.filename):
        file_id = _save_file(file_obj, u, record_id)

    log_event('DATA_CREATE', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'],
              resource_tenant_id=u['tenant_id'])
    return jsonify({'message': 'Record created', 'id': record_id, 'file_id': file_id}), 201

def _save_file(file_obj, u, record_id=None):
    """Save file to S3 or local disk. Returns file DB id."""
    original_name = secure_filename(file_obj.filename)
    mime_type     = file_obj.content_type or \
                    mimetypes.guess_type(original_name)[0] or 'application/octet-stream'
    file_data     = file_obj.read()
    file_size     = len(file_data)
    s3_key        = None
    local_path    = None

    if USE_AWS:
        s3_key = f"tenant-{u['tenant_id']}/{uuid.uuid4().hex}/{original_name}"
        get_s3().put_object(
            Bucket=S3_BUCKET, Key=s3_key, Body=file_data,
            ContentType=mime_type,
            Metadata={'tenant_id': str(u['tenant_id']), 'uploaded_by': str(u['id'])}
        )
    else:
        tenant_dir  = os.path.join(UPLOAD_FOLDER, f"tenant_{u['tenant_id']}")
        os.makedirs(tenant_dir, exist_ok=True)
        unique_name = f"{uuid.uuid4().hex}_{original_name}"
        local_path  = os.path.join(tenant_dir, unique_name)
        with open(local_path, 'wb') as fp:
            fp.write(file_data)

    conn = db()
    cur  = conn.execute(
        "INSERT INTO tenant_files "
        "(tenant_id,record_id,uploaded_by,original_name,s3_key,local_path,file_size,mime_type) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (u['tenant_id'], record_id, u['id'], original_name,
         s3_key, local_path, file_size, mime_type)
    )
    conn.commit()
    return cur.lastrowid

@app.route('/api/data/<int:rid>')
@jwt_required
def get_record(rid):
    u   = current_user()
    row = db().execute("SELECT * FROM tenant_data WHERE id=?", (rid,)).fetchone()
    if not row: return jsonify({'error': 'Record not found'}), 404
    if row['tenant_id'] != u['tenant_id']:
        log_event('CROSS_TENANT_ACCESS_ATTEMPT', 'BLOCKED',
                  user_id=u['id'], tenant_id=u['tenant_id'],
                  resource_tenant_id=row['tenant_id'],
                  details=f"{u['username']} tried record {rid}")
        return jsonify({'error': 'Access denied — tenant isolation enforced'}), 403
    f = db().execute(
        "SELECT id, original_name, file_size, mime_type FROM tenant_files WHERE record_id=? LIMIT 1",
        (rid,)
    ).fetchone()
    log_event('DATA_ACCESS', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'],
              resource_tenant_id=row['tenant_id'])
    return jsonify({
        'id': row['id'], 'tenant_id': row['tenant_id'], 'title': row['title'],
        'content': decrypt_data(row['content']), 'data_type': row['data_type'],
        'created_at': row['created_at'],
        'file': dict(f) if f else None
    })

@app.route('/api/data/<int:rid>', methods=['DELETE'])
@jwt_required
def delete_record(rid):
    u   = current_user()
    row = db().execute("SELECT * FROM tenant_data WHERE id=?", (rid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if row['tenant_id'] != u['tenant_id']:
        log_event('CROSS_TENANT_DELETE_ATTEMPT', 'BLOCKED',
                  user_id=u['id'], tenant_id=u['tenant_id'])
        return jsonify({'error': 'Access denied'}), 403
    # delete attached files
    files = db().execute("SELECT * FROM tenant_files WHERE record_id=?", (rid,)).fetchall()
    for f in files:
        _delete_file_storage(f)
    db().execute("DELETE FROM tenant_files WHERE record_id=?", (rid,))
    db().execute("DELETE FROM tenant_data WHERE id=?", (rid,))
    db().commit()
    log_event('DATA_DELETE', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'])
    return jsonify({'message': 'Record deleted'})

# ── File Endpoints ────────────────────────────────────────────────────────────
@app.route('/api/files/upload', methods=['POST'])
@jwt_required
def upload_standalone_file():
    """Standalone file upload (not attached to a record)."""
    u = current_user()
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    f = request.files['file']
    if not f.filename or not allowed_file(f.filename):
        return jsonify({'error': 'Invalid or disallowed file'}), 400
    file_id = _save_file(f, u, record_id=None)
    log_event('FILE_UPLOAD', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'])
    return jsonify({'message': 'File uploaded', 'id': file_id}), 201

@app.route('/api/files')
@jwt_required
def list_files():
    u    = current_user()
    rows = db().execute(
        "SELECT f.*, u2.username FROM tenant_files f "
        "LEFT JOIN users u2 ON u2.id = f.uploaded_by "
        "WHERE f.tenant_id=? ORDER BY f.created_at DESC", (u['tenant_id'],)
    ).fetchall()
    return jsonify({'files': [{
        'id': r['id'], 'original_name': r['original_name'],
        'file_size': r['file_size'], 'mime_type': r['mime_type'],
        'created_at': r['created_at'], 'uploaded_by': r['username'],
        'record_id': r['record_id'], 'has_s3': bool(r['s3_key'])
    } for r in rows]})

@app.route('/api/files/<int:fid>')
@jwt_required
def download_file(fid):
    u   = current_user()
    row = db().execute("SELECT * FROM tenant_files WHERE id=?", (fid,)).fetchone()
    if not row: return jsonify({'error': 'File not found'}), 404
    if row['tenant_id'] != u['tenant_id']:
        log_event('FILE_ACCESS_BLOCKED', 'BLOCKED', user_id=u['id'],
                  tenant_id=u['tenant_id'], resource_tenant_id=row['tenant_id'])
        return jsonify({'error': 'Access denied'}), 403
    log_event('FILE_ACCESS', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'])
    if USE_AWS and row['s3_key']:
        obj  = get_s3().get_object(Bucket=S3_BUCKET, Key=row['s3_key'])
        data = obj['Body'].read()
        return send_file(io.BytesIO(data), mimetype=row['mime_type'],
                         download_name=row['original_name'])
    elif row['local_path'] and os.path.exists(row['local_path']):
        return send_file(row['local_path'], mimetype=row['mime_type'],
                         download_name=row['original_name'])
    return jsonify({'error': 'File data missing'}), 404

@app.route('/api/files/<int:fid>', methods=['DELETE'])
@jwt_required
def delete_file(fid):
    u   = current_user()
    row = db().execute("SELECT * FROM tenant_files WHERE id=?", (fid,)).fetchone()
    if not row: return jsonify({'error': 'Not found'}), 404
    if row['tenant_id'] != u['tenant_id']:
        return jsonify({'error': 'Access denied'}), 403
    _delete_file_storage(row)
    db().execute("DELETE FROM tenant_files WHERE id=?", (fid,))
    db().commit()
    log_event('FILE_DELETE', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'])
    return jsonify({'message': 'File deleted'})

def _delete_file_storage(row):
    if USE_AWS and row['s3_key']:
        try: get_s3().delete_object(Bucket=S3_BUCKET, Key=row['s3_key'])
        except Exception: pass
    elif row['local_path'] and os.path.exists(row['local_path']):
        try: os.remove(row['local_path'])
        except Exception: pass

# ── AI Analysis ───────────────────────────────────────────────────────────────
@app.route('/api/ai/analyze', methods=['POST'])
@jwt_required
def ai_analyze():
    u       = current_user()
    data    = request.get_json() or {}
    content = data.get('content', '')
    prompt  = data.get('prompt') or \
              f"Analyze this business record and provide: 1) Summary, 2) Classification, " \
              f"3) Privacy risk level, 4) Key insights.\n\nContent: {content}"

    if USE_AWS:
        import json
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 512,
            "messages": [{"role": "user", "content": prompt}]
        })
        resp     = get_bedrock().invoke_model(
            modelId='anthropic.claude-3-sonnet-20240229-v1:0', body=body)
        result   = json.loads(resp['body'].read())
        analysis = result['content'][0]['text']
        source   = 'aws-bedrock'
    else:
        analysis = (
            f"📊 AI Analysis (Demo Mode):\n\n"
            f"Content: '{content[:80]}…'\n\n"
            f"• Classification: Business Intelligence\n"
            f"• Sensitivity: High\n"
            f"• Recommendation: Restrict to authorised users only\n"
            f"• Tags: #confidential #tenant-{u['tenant_id']}\n\n"
            f"Set USE_S3=true + AWS credentials to use real Claude via Bedrock."
        )
        source = 'demo'

    log_event('AI_ANALYSIS', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'],
              details=source)
    return jsonify({'analysis': analysis, 'source': source})

# ── Attack Simulation ─────────────────────────────────────────────────────────
@app.route('/api/simulate/attack', methods=['POST'])
@jwt_required
def simulate_attack():
    u    = current_user()
    data = request.get_json() or {}
    rid  = data.get('target_record_id')
    row  = db().execute("SELECT * FROM tenant_data WHERE id=?", (rid,)).fetchone()
    if not row:
        return jsonify({'message': 'Record not found'}), 404
    if row['tenant_id'] != u['tenant_id']:
        log_event('CROSS_TENANT_ACCESS_ATTEMPT', 'BLOCKED',
                  user_id=u['id'], tenant_id=u['tenant_id'],
                  resource_tenant_id=row['tenant_id'],
                  details='Simulated cross-tenant attack')
        return jsonify({
            'result':          'BLOCKED',
            'message':         '🛡 Tenant isolation enforced — access denied!',
            'attacker_tenant': u['tenant_id'],
            'target_tenant':   row['tenant_id']
        }), 403
    # Same tenant — return the record
    f = db().execute(
        "SELECT original_name FROM tenant_files WHERE record_id=? LIMIT 1", (rid,)
    ).fetchone()
    log_event('DATA_ACCESS', 'SUCCESS', user_id=u['id'], tenant_id=u['tenant_id'],
              resource_tenant_id=row['tenant_id'])
    return jsonify({
        'result':  'OWN_RECORD',
        'message': 'This is your own record — access granted.',
        'record':  {
            'id':      row['id'],
            'title':   row['title'],
            'content': decrypt_data(row['content']),
            'type':    row['data_type'],
            'file':    f['original_name'] if f else None
        }
    })

# ── Admin ─────────────────────────────────────────────────────────────────────
@app.route('/api/admin/metrics')
@jwt_required
def get_metrics():
    u = current_user()
    if u['role'] != 'admin': return jsonify({'error': 'Admin only'}), 403
    return jsonify(metrics_module.calculate_metrics(db()))

@app.route('/api/admin/logs')
@jwt_required
def get_logs():
    u     = current_user()
    if u['role'] != 'admin': return jsonify({'error': 'Admin only'}), 403
    limit = int(request.args.get('limit', 50))
    rows  = db().execute(
        "SELECT * FROM security_logs ORDER BY timestamp DESC LIMIT ?", (limit,)
    ).fetchall()
    return jsonify({'logs': [dict(r) for r in rows]})

@app.route('/api/admin/tenants')
@jwt_required
def get_tenants():
    u    = current_user()
    if u['role'] != 'admin': return jsonify({'error': 'Admin only'}), 403
    rows = db().execute("SELECT * FROM tenants").fetchall()
    result = []
    for t in rows:
        uc = db().execute("SELECT COUNT(*) as c FROM users WHERE tenant_id=?", (t['id'],)).fetchone()['c']
        rc = db().execute("SELECT COUNT(*) as c FROM tenant_data WHERE tenant_id=?", (t['id'],)).fetchone()['c']
        fc = db().execute("SELECT COUNT(*) as c FROM tenant_files WHERE tenant_id=?", (t['id'],)).fetchone()['c']
        result.append({'id': t['id'], 'name': t['name'], 'plan': t['plan'],
                       'user_count': uc, 'record_count': rc, 'file_count': fc})
    return jsonify({'tenants': result})

# ── Seed Demo Data ────────────────────────────────────────────────────────────
def seed_data():
    conn = get_db()
    if conn.execute("SELECT COUNT(*) as c FROM tenants").fetchone()['c'] > 0:
        conn.close(); return
    conn.execute("INSERT INTO tenants (name,plan) VALUES ('Alpha Corp','enterprise')")
    conn.execute("INSERT INTO tenants (name,plan) VALUES ('Beta Ltd','pro')")
    conn.execute("INSERT INTO tenants (name,plan) VALUES ('Gamma Inc','basic')")
    conn.commit()
    t1 = conn.execute("SELECT id FROM tenants WHERE name='Alpha Corp'").fetchone()['id']
    t2 = conn.execute("SELECT id FROM tenants WHERE name='Beta Ltd'").fetchone()['id']
    t3 = conn.execute("SELECT id FROM tenants WHERE name='Gamma Inc'").fetchone()['id']

    def add_user(username, email, password, tid, role='user'):
        conn.execute(
            "INSERT INTO users (username,email,password_hash,role,tenant_id) VALUES (?,?,?,?,?)",
            (username, email, generate_password_hash(password), role, tid)
        )
    add_user('admin',   'admin@alphacorp.com',  'Admin@1234',   t1, 'admin')
    add_user('alice',   'alice@alphacorp.com',  'Alice@1234',   t1)
    add_user('bob',     'bob@betaltd.com',       'Bob@1234',     t2)
    add_user('charlie', 'charlie@gammainc.com', 'Charlie@1234', t3)
    conn.commit()

    aid  = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()['id']
    alid = conn.execute("SELECT id FROM users WHERE username='alice'").fetchone()['id']
    bid  = conn.execute("SELECT id FROM users WHERE username='bob'").fetchone()['id']
    cid  = conn.execute("SELECT id FROM users WHERE username='charlie'").fetchone()['id']

    for s in [
        (t1, 'Alpha Sales Report Q1', encrypt_data('Revenue: $4.5M, Growth: 12%'),    'financial', aid),
        (t1, 'Alpha Employee List',   encrypt_data('John, Jane, Mark — 250 employees'),'hr',       alid),
        (t2, 'Beta Product Roadmap',  encrypt_data('Q2: Launch v2, Q3: AI features'),  'product',  bid),
        (t2, 'Beta Customer List',    encrypt_data('Customers: Nike, Adidas, Puma'),   'crm',      bid),
        (t3, 'Gamma Internal Memo',   encrypt_data('Meeting at 3pm: discuss merger'),  'general',  cid),
    ]:
        conn.execute(
            "INSERT INTO tenant_data (tenant_id,title,content,data_type,created_by) VALUES (?,?,?,?,?)", s
        )
    conn.commit(); conn.close()
    print("\n" + "="*54)
    print("  ✅  Database seeded with demo data!")
    print("="*54)
    print("  admin   / Admin@1234   → Alpha Corp (ADMIN)")
    print("  alice   / Alice@1234   → Alpha Corp")
    print("  bob     / Bob@1234     → Beta Ltd")
    print("  charlie / Charlie@1234 → Gamma Inc")
    print("  Open → http://localhost:5000")
    print("="*54 + "\n")

if __name__ == '__main__':
    init_schema()
    seed_data()
    app.run(debug=True, host='0.0.0.0', port=5000)
