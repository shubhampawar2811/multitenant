"""
AES-256 Encryption Utility for Multi-Tenant Data Isolation
"""
import os
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

# Fixed 32-byte AES-256 key (in production, load from env securely)
ENCRYPTION_KEY = b'multitenantsecurekey1234567890ab'  # exactly 32 bytes


def encrypt_data(plaintext: str) -> str:
    """Encrypt data using AES-256-CBC and return base64-encoded string."""
    if not plaintext:
        return plaintext
    iv = os.urandom(16)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext.encode()) + padder.finalize()
    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ct = encryptor.update(padded) + encryptor.finalize()
    return base64.b64encode(iv + ct).decode('utf-8')


def decrypt_data(ciphertext: str) -> str:
    """Decrypt AES-256-CBC base64-encoded data."""
    if not ciphertext:
        return ciphertext
    try:
        raw = base64.b64decode(ciphertext.encode('utf-8'))
        iv = raw[:16]
        ct = raw[16:]
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        padded = decryptor.update(ct) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        plaintext = unpadder.update(padded) + unpadder.finalize()
        return plaintext.decode('utf-8')
    except Exception:
        return "[Decryption Error]"
