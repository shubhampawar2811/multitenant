# 🛡 Multi-Tenant Cloud — Full Setup Guide

## What This App Does
- Multiple companies (tenants) share ONE app but their data is 100% isolated
- Every user sees ALL record titles globally but can ONLY read/access their own tenant's data
- File/document upload attached to records (local disk or AWS S3)
- Cross-tenant attack simulation with full audit logging
- AWS Bedrock Claude AI analysis of your records
- Add new users and tenants at runtime — no restart needed

---

## Demo Accounts (auto-created on first run)

| Username | Password    | Tenant      | Role  |
|----------|-------------|-------------|-------|
| admin    | Admin@1234  | Alpha Corp  | admin |
| alice    | Alice@1234  | Alpha Corp  | user  |
| bob      | Bob@1234    | Beta Ltd    | user  |
| charlie  | Charlie@1234| Gamma Inc   | user  |

---

## Step-by-Step: Run Locally

### Step 1 — Make sure Python is installed
```
python --version
```
You need Python 3.8 or higher. Download from https://python.org if needed.

### Step 2 — Download / extract the project
Put the `multi_tenant_cloud` folder anywhere on your computer, e.g.:
```
C:\Projects\multi_tenant_cloud      (Windows)
~/Projects/multi_tenant_cloud       (Mac/Linux)
```

### Step 3 — Open a terminal in the project folder
- **Windows**: Open Command Prompt or PowerShell, then:
  ```
  cd C:\Projects\multi_tenant_cloud
  ```
- **Mac/Linux**: Open Terminal, then:
  ```
  cd ~/Projects/multi_tenant_cloud
  ```

### Step 4 — Create a virtual environment
```
python -m venv venv
```

### Step 5 — Activate the virtual environment
- **Windows**:
  ```
  venv\Scripts\activate
  ```
- **Mac/Linux**:
  ```
  source venv/bin/activate
  ```
You will see `(venv)` at the start of your terminal line.

### Step 6 — Install all dependencies
```
pip install -r requirements.txt
```
This installs Flask, JWT, cryptography, boto3 (AWS), etc.

### Step 7 — Run the app
```
python app.py
```

You will see:
```
✅  Database seeded with demo data!
  admin   / Admin@1234   → Alpha Corp (ADMIN)
  alice   / Alice@1234   → Alpha Corp
  bob     / Bob@1234     → Beta Ltd
  charlie / Charlie@1234 → Gamma Inc
  Open → http://localhost:5000
```

### Step 8 — Open in browser
Go to: http://localhost:5000

Login with any demo account and explore!

---

## How to Add a New User at Runtime

**Option A — Via the Register page:**
1. Go to http://localhost:5000/login-page
2. Click the "Register" tab
3. Fill in username, email, password
4. For `tenant_name`: enter an EXISTING tenant name to join it, or a NEW name to create a new tenant
5. Click Register → Login

**Option B — Via API (Postman or curl):**
```
POST http://localhost:5000/api/auth/register
Content-Type: application/json

{
  "username": "david",
  "email": "david@deltainc.com",
  "password": "David@1234",
  "tenant_name": "Delta Inc"
}
```

The new user and tenant are created instantly. Login immediately.

---

## Enable AWS Features (Optional)

### AWS S3 for File Storage
1. Create an S3 bucket in AWS Console
2. Create an IAM user with S3 read/write permissions
3. Set environment variables before running:

**Windows:**
```
set USE_S3=true
set S3_BUCKET=your-bucket-name
set AWS_REGION=us-east-1
set AWS_ACCESS_KEY_ID=your-key-id
set AWS_SECRET_ACCESS_KEY=your-secret
python app.py
```

**Mac/Linux:**
```
export USE_S3=true
export S3_BUCKET=your-bucket-name
export AWS_REGION=us-east-1
export AWS_ACCESS_KEY_ID=your-key-id
export AWS_SECRET_ACCESS_KEY=your-secret
python app.py
```

### AWS Bedrock (Claude AI Analysis)
1. Enable USE_S3=true (same flag enables Bedrock)
2. In AWS Console → Bedrock → Model Access → Enable "Claude 3 Sonnet"
3. Your IAM user needs `bedrock:InvokeModel` permission

---

## Deploy to AWS (Production)

### Option A — EC2 (Simple)
```bash
# On your EC2 instance (Amazon Linux 2):
sudo yum install python3 python3-pip -y
git clone <your-repo> /home/ec2-user/app
cd /home/ec2-user/app/multi_tenant_cloud
pip3 install -r requirements.txt

# Run with gunicorn (production server):
pip3 install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Option B — ECS Fargate (Scalable, Recommended)

**1. Build Docker image:**
```bash
docker build -t multitenant-cloud .
```

**2. Push to AWS ECR:**
```bash
aws ecr create-repository --repository-name multitenant-cloud
aws ecr get-login-password | docker login --username AWS --password-stdin <account>.dkr.ecr.<region>.amazonaws.com
docker tag multitenant-cloud:latest <account>.dkr.ecr.<region>.amazonaws.com/multitenant-cloud:latest
docker push <account>.dkr.ecr.<region>.amazonaws.com/multitenant-cloud:latest
```

**3. Create ECS Cluster + Service + ALB in AWS Console**

**4. Set environment variables in ECS Task Definition:**
```
USE_S3=true
S3_BUCKET=your-bucket
AWS_REGION=us-east-1
JWT_SECRET=your-64-char-random-secret
```

**5. Attach Route 53 domain + CloudFront for HTTPS**

---

## Project Structure

```
multi_tenant_cloud/
├── app.py              ← Main Flask app (all API routes)
├── database.py         ← SQLite schema + connection helper
├── encryption.py       ← AES-256 encrypt/decrypt
├── metrics.py          ← Security metrics calculator
├── requirements.txt    ← Python dependencies
├── .env.example        ← Environment variable template
├── instance/
│   ├── multitenant.db  ← SQLite database (auto-created)
│   └── uploads/        ← Uploaded files (local mode)
└── templates/
    ├── index.html      ← Landing page
    ├── login.html      ← Login / Register
    ├── dashboard.html  ← Main user dashboard
    └── admin.html      ← Admin panel
```

## API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/auth/register | Register new user + tenant |
| POST | /api/auth/login | Login, get JWT token |
| GET | /api/me | Get current user info |
| GET | /api/data/all | All tenants — global view |
| GET | /api/data | My tenant records only |
| POST | /api/data | Add record (+ optional file) |
| GET | /api/data/:id | Get single record (own tenant only) |
| DELETE | /api/data/:id | Delete record (own tenant only) |
| GET | /api/files | List my tenant files |
| GET | /api/files/:id | Download/view file |
| DELETE | /api/files/:id | Delete file |
| POST | /api/ai/analyze | AWS Bedrock AI analysis |
| POST | /api/simulate/attack | Cross-tenant attack simulation |
| GET | /api/admin/metrics | Admin: security metrics |
| GET | /api/admin/logs | Admin: audit logs |
| GET | /api/admin/tenants | Admin: all tenants |

---

## Troubleshooting

**"ModuleNotFoundError: No module named 'flask'"**
→ Make sure your virtual environment is activated (Step 5)

**"Port 5000 already in use"**
→ Change port in app.py last line: `app.run(port=8080)`

**"Database locked"**
→ Stop any other running instances of the app

**Files not uploading**
→ Check the `instance/uploads/` folder exists (auto-created on first run)

**AWS errors**
→ Check AWS credentials are set correctly
→ Make sure IAM user has S3 + Bedrock permissions
