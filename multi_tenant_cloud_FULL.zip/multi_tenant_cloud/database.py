"""
Database layer — sqlite3 built-in.
Tables: tenants, users, tenant_data, tenant_files, security_logs
"""
import sqlite3, os

DB_PATH = os.path.join(os.path.dirname(__file__), 'instance', 'multitenant.db')

def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_schema():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS tenants (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT UNIQUE NOT NULL,
            plan       TEXT DEFAULT 'basic',
            created_at TEXT DEFAULT (datetime('now')),
            is_active  INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT UNIQUE NOT NULL,
            email         TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role          TEXT DEFAULT 'user',
            tenant_id     INTEGER NOT NULL REFERENCES tenants(id),
            created_at    TEXT DEFAULT (datetime('now')),
            is_active     INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS tenant_data (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id    INTEGER NOT NULL REFERENCES tenants(id),
            title        TEXT NOT NULL,
            content      TEXT NOT NULL,
            data_type    TEXT DEFAULT 'general',
            created_by   INTEGER REFERENCES users(id),
            created_at   TEXT DEFAULT (datetime('now')),
            is_sensitive INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS tenant_files (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id     INTEGER NOT NULL REFERENCES tenants(id),
            record_id     INTEGER REFERENCES tenant_data(id),
            uploaded_by   INTEGER REFERENCES users(id),
            original_name TEXT NOT NULL,
            s3_key        TEXT,
            local_path    TEXT,
            file_size     INTEGER DEFAULT 0,
            mime_type     TEXT DEFAULT 'application/octet-stream',
            description   TEXT DEFAULT '',
            created_at    TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS security_logs (
            id                 INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp          TEXT DEFAULT (datetime('now')),
            user_id            INTEGER,
            tenant_id          INTEGER,
            action             TEXT NOT NULL,
            resource_tenant_id INTEGER,
            status             TEXT NOT NULL,
            ip_address         TEXT,
            details            TEXT
        );
        """)
